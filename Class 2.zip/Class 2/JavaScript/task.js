class Task {
  constructor(
    important,
    title,
    description,
    dueDate,
    color,
    emoji,
    location,
    status,
    notification
  ) {
    this.important = important;
    this.title = title;
    this.description = description;
    this.dueDate = dueDate;
    this.color = color;
    this.emoji = emoji;
    this.location = location;
    this.status = status;
    this.notification = notification;

    this.name = "sergio";
  }
}
